from django.apps import AppConfig


class DeviseConfig(AppConfig):
    name = 'devise'
